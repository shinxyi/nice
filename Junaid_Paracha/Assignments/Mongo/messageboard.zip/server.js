var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');
var mongoose = require('mongoose');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/MessageBoard');

var Schema = mongoose.Schema;
var MessageSchema = new mongoose.Schema({
	name: {type: String, required: true},
	text: {type: String, required: true }, 
	comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
	}, {timestamps: true });
var CommentSchema = new mongoose.Schema({
	name: {type: String, required: true},
	_message: {type: Schema.Types.ObjectId, ref: 'Message'},
	text: {type: String, required: true }
	}, {timestamp: true });

mongoose.model('Message', MessageSchema);
mongoose.model('Comment', CommentSchema);

var Message = mongoose.model('Message');
var Comment = mongoose.model('Comment');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');



app.get('/', function(req, res) {

	Message.find({})
	.populate('comments')
	.exec(function(err, messages) {
    	if(err) {
			console.log('something went wrong');
		} 
		else { 
			console.log('successfully added a user!');
			console.log(messages)
			res.render('index', {message: messages});
    	}
	})
	

	// res.render('index');
})
app.post('/message', function(req, res) {
    console.log("POST DATA", req.body);

	var message = new Message({name: req.body.name, text: req.body.message});

	message.save(function(err) {
		if(err) {
		console.log('something went wrong');
		} 
		else { 
		console.log('successfully added an Message!');
    	res.redirect('/');
    	}
	})
})

app.get('/posts/:id', function (req, res){
	Post.findOne({_id: req.params.id})
	.populate('comments')
	.exec(function(err, post) {
     	res.render('message', {message: message});
    });
});
app.post('/posts/:id', function (req, res){
	Message.findOne({_id: req.params.id}, function(err, message){
        var comment = new Comment({text:req.body.comment, name: req.body.name});
        comment._message = Message._id;
        message.comments.push(comment);
        comment.save(function(err){
            message.save(function(err){
                if(err) { console.log('Error'); } 
                else { res.redirect('/'); }
            });
        });
   	});
});


app.listen(8000, function() {
    console.log("listening on port 8000");
})

app.post('/update', function(req, res) {

	res.redirect('/');
})
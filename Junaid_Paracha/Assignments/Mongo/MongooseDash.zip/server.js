// Require the Express Module
var express = require('express');
// Create an Express App
var app = express();

var mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/animal');
var AnimalSchema = new mongoose.Schema({
 name: String,
 type: String,
 age: Number,
 color: String,
 dateAdded: Date
})
mongoose.model('Animal', AnimalSchema); // We are setting this Schema in our Models as 'User'
var Animal = mongoose.model('Animal') // We are retrieving this Schema from our Models, named 'User'


// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
app.use(bodyParser.urlencoded({ extended: true }));
// Require path
var path = require('path');
// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    
    Animal.find({}, function(err, animals) {
    	if(err) {
			console.log('something went wrong');
		} 
		else { 
			console.log('successfully added a user!');
			res.render('index', {animal: animals});
    	}
	})
})
app.get('/delete/:id', function(req, res) {
    // This is where we will retrieve the users from the database and include them in the view page we will be rendering.
    console.log("The user id requested is:", req.params.id);
    // just to illustrate that req.params is usable here:
    // res.send("You requested the user with id: " + req.params.id);
    // code to get user from db goes here, etc...
    
    Animal.remove({_id: req.params.id}, function(err, Animals) {
    	if(err) {
			console.log('something went wrong');
		} 
		else { 
			console.log('successfully added a user!');
			res.redirect('/');
    	}
	})

})
// Add User Request 
app.post('/animal', function(req, res) {
    console.log("POST DATA", req.body);
    // This is where we would add the user from req.body to the database.
    // create a new User with the name and age corresponding to those from req.body
	var animal = new Animal({name: req.body.name, type: req.body.type, age: req.body.age, color: req.body.color, dateAdded: req.body.dateAdded});

	// Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
	animal.save(function(err) {
	// if there is an error console.log that something went wrong!
		if(err) {
		console.log('something went wrong');
		} 
		else { // else console.log that we did well and then redirect to the root route
		console.log('successfully added an Animal!');
    	res.redirect('/');
    	}
	})
})
app.post('/update', function(req, res) {
    console.log("POST DATA", req.body);
    console.log(req.body.name);
    // Example:
	// db.ninjas.update({name: "Trey"}, {$set: {location: "Mountain View"}})

	Animal.update({_id:req.body.id}, {name:req.body.name}, function(err){
			console.log(err);
		 // This code will run when the DB has attempted to update the matching record.
		})
	// 	// another way to update a record
	// 	Animal.findOne({name: 'Andriana'}, function(err, user){
	// 		animal.name = 'Andri'
	// 		animal.save(function(err){
	// 	     // if save was successful awesome!
	// 	 	})
	// 	})
	res.redirect('/');
})
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})
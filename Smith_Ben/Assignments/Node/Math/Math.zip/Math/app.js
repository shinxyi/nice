

var math_module = require('./mathlib');
math_module.add(2,3);
math_module.multiply(3,5);
math_module.square(5);
math_module.random(10,100);